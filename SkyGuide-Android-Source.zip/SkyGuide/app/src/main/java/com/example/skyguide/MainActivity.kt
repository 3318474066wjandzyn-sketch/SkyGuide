package com.example.skyguide

import android.Manifest
import android.content.Context
import android.content.ContentValues
import android.graphics.Bitmap
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.appcompat.app.AlertDialog
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var skyOverlay: SkyOverlay
    private lateinit var status: TextView
    private lateinit var rootView: FrameLayout
    private lateinit var sensorManager: SensorManager
    private var azimuthDeg = 0f
    private var pitchDeg = 0f
    private var rollDeg = 0f
    private var location: Location? = null
    private lateinit var cameraExecutor: ExecutorService

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) updateLocation()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
        val wanted = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        permissionLauncher.launch(wanted.toTypedArray())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        updateLocation()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        rootView = root
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        skyOverlay = SkyOverlay(this)
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        root.addView(skyOverlay, FrameLayout.LayoutParams(-1, -1))
        status = TextView(this).apply {
            text = "星空识别 · 将手机对准天空"
            textSize = 15f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(28, 52, 28, 24)
            setShadowLayer(6f, 0f, 2f, android.graphics.Color.BLACK)
        }
        root.addView(status, FrameLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0x66060B1A)
        }
        fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; isAllCaps = false
            setOnClickListener { action() }
        }
        controls.addView(actionButton("搜索天体") { showStarSearch() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(actionButton("校准" ) { showCalibration() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(actionButton("保存画面") { saveScreenshot() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls, FrameLayout.LayoutParams(-1, -2, android.view.Gravity.TOP or android.view.Gravity.END).apply { topMargin = 108 })
        val hint = TextView(this).apply {
            text = "AR 星图 · 方向精度受手机磁力计、镜头视场角和姿态影响"
            textSize = 12f
            setTextColor(0xFFE2F7FF.toInt())
            setPadding(20, 14, 20, 22)
            setBackgroundColor(0x55060B1A)
        }
        val lp = FrameLayout.LayoutParams(-1, -2, android.view.Gravity.BOTTOM)
        root.addView(hint, lp)
        setContentView(root)
    }

    private fun showStarSearch() {
        val catalog = skyOverlay.starCatalog().sortedBy { it.name }
        val names = catalog.map { "${it.name}  ·  ${it.constellation}  ·  星等 ${it.magnitude}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("亮星目录（原型版）")
            .setItems(names) { _, which ->
                skyOverlay.highlightName = catalog[which].name
                skyOverlay.invalidate()
                Toast.makeText(this, "已高亮 ${catalog[which].name}；转动手机寻找标记", Toast.LENGTH_LONG).show()
            }
            .setPositiveButton("关闭", null).show()
    }

    private fun showCalibration() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 8, 32, 8) }
        val headingLabel = TextView(this).apply { text = "方位微调：${skyOverlay.headingOffset.toInt()}°" }
        val headingBar = SeekBar(this).apply { max = 720; progress = (skyOverlay.headingOffset + 360f).toInt().coerceIn(0, 720) }
        headingBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                skyOverlay.headingOffset = progress - 360f; headingLabel.text = "方位微调：${skyOverlay.headingOffset.toInt()}°"; skyOverlay.invalidate()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val pitchLabel = TextView(this).apply { text = "仰角微调：${skyOverlay.pitchOffset.toInt()}°" }
        val pitchBar = SeekBar(this).apply { max = 120; progress = (skyOverlay.pitchOffset + 60f).toInt().coerceIn(0, 120) }
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                skyOverlay.pitchOffset = progress - 60f; pitchLabel.text = "仰角微调：${skyOverlay.pitchOffset.toInt()}°"; skyOverlay.invalidate()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(headingLabel); box.addView(headingBar); box.addView(pitchLabel); box.addView(pitchBar)
        AlertDialog.Builder(this).setTitle("星图对齐校准").setMessage("对准已知亮星后微调。此功能只能修正整体偏差，不能替代设备级传感器/镜头校准。")
            .setView(box).setNegativeButton("重置") { _, _ -> skyOverlay.headingOffset = 0f; skyOverlay.pitchOffset = 0f; skyOverlay.invalidate() }
            .setPositiveButton("完成", null).show()
    }

    private fun saveScreenshot() {
        try {
            val bitmap = Bitmap.createBitmap(rootView.width, rootView.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            rootView.draw(canvas)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "SkyGuide-${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SkyGuide")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建图片文件")
            contentResolver.openOutputStream(uri)?.use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
            bitmap.recycle()
            Toast.makeText(this, "星空画面已保存到相册 / Pictures/SkyGuide", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "保存失败：${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            } catch (e: Exception) { Toast.makeText(this, "无法启动相机：${e.localizedMessage}", Toast.LENGTH_LONG).show() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            location = Location("default").apply { latitude = 26.58; longitude = 106.71 }
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            val last = providers.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            location = last ?: Location("default").apply { latitude = 26.58; longitude = 106.71 }
        } catch (_: Exception) {
            location = Location("default").apply { latitude = 26.58; longitude = 106.71 }
        }
        skyOverlay.location = location
        skyOverlay.invalidate()
    }

    override fun onResume() {
        super.onResume()
        val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        else {
            sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_GAME)
        }
    }
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }
    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val matrix = FloatArray(9); val orient = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(matrix, event.values)
            SensorManager.getOrientation(matrix, orient)
            azimuthDeg = ((Math.toDegrees(orient[0].toDouble()).toFloat() + 360f) % 360f)
            pitchDeg = Math.toDegrees(orient[1].toDouble()).toFloat()
            rollDeg = Math.toDegrees(orient[2].toDouble()).toFloat()
        } else if (event.values.size >= 3) {
            azimuthDeg = event.values[0]; pitchDeg = event.values[1]; rollDeg = event.values[2]
        }
        skyOverlay.heading = azimuthDeg
        skyOverlay.pitch = pitchDeg
        skyOverlay.roll = rollDeg
        skyOverlay.location = location
        skyOverlay.invalidate()
        status.text = "星空识别 · 方位 ${azimuthDeg.toInt()}° · 仰角传感器 ${pitchDeg.toInt()}°"
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

data class SkyStar(val name: String, val raHours: Double, val decDeg: Double, val constellation: String, val magnitude: Double)
data class SkyPoint(val star: SkyStar, val x: Float, val y: Float)

class SkyOverlay(context: Context) : android.view.View(context) {
    var heading = 0f
    var pitch = 0f
    var roll = 0f
    var headingOffset = 0f
    var pitchOffset = 0f
    var highlightName: String? = null
    var location: Location? = null
    private val linePaint = android.graphics.Paint(3).apply { color = 0xCC76DFFF.toInt(); strokeWidth = 2f; style = android.graphics.Paint.Style.STROKE }
    private val starPaint = android.graphics.Paint(3).apply { color = 0xFFFFF4C2.toInt(); style = android.graphics.Paint.Style.FILL }
    private val textPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.WHITE; textSize = 28f; setShadowLayer(5f, 1f, 1f, android.graphics.Color.BLACK) }
    private val labelPaint = android.graphics.Paint(3).apply { color = 0xFF8FEAFF.toInt(); textSize = 22f; setShadowLayer(5f, 1f, 1f, android.graphics.Color.BLACK) }

    // A small bright-star catalogue. For production, replace with a full validated catalogue.
    private val stars = listOf(
        SkyStar("天狼星", 6.752, -16.72, "大犬座", -1.46), SkyStar("参宿四", 5.919, 7.41, "猎户座", 0.5),
        SkyStar("参宿七", 5.242, -8.20, "猎户座", 0.13), SkyStar("参宿一", 5.603, -1.20, "猎户座", 1.7),
        SkyStar("参宿二", 5.533, -0.30, "猎户座", 1.7), SkyStar("参宿三", 5.679, -1.94, "猎户座", 2.2),
        SkyStar("毕宿五", 4.599, 16.51, "金牛座", 0.85), SkyStar("五车二", 5.278, 45.998, "御夫座", 0.08),
        SkyStar("北极星", 2.530, 89.264, "小熊座", 1.98), SkyStar("织女星", 18.616, 38.78, "天琴座", 0.03),
        SkyStar("天津四", 20.690, 45.28, "天鹅座", 1.25), SkyStar("牛郎星", 19.846, 8.87, "天鹰座", 0.77),
        SkyStar("大角星", 14.261, 19.18, "牧夫座", -0.05), SkyStar("角宿一", 13.420, -11.16, "室女座", 0.98),
        SkyStar("心宿二", 16.490, -26.43, "天蝎座", 1.06), SkyStar("南河三", 7.655, 5.22, "小犬座", 0.34),
        SkyStar("轩辕十四", 10.139, 11.97, "狮子座", 1.35), SkyStar("北河三", 7.755, 28.03, "双子座", 1.14),
        SkyStar("北河二", 7.576, 31.89, "双子座", 1.58), SkyStar("角宿一", 13.420, -11.16, "室女座", 0.98),
        SkyStar("河鼓二", 19.846, 8.87, "天鹰座", 0.77), SkyStar("摇光", 13.792, 49.31, "大熊座", 1.77),
        SkyStar("天枢", 11.062, 61.75, "大熊座", 1.79), SkyStar("天璇", 11.031, 56.38, "大熊座", 2.37),
        SkyStar("天玑", 11.897, 53.69, "大熊座", 2.44), SkyStar("天权", 12.257, 57.03, "大熊座", 3.3),
        SkyStar("玉衡", 12.900, 55.96, "大熊座", 1.77), SkyStar("开阳", 13.399, 54.93, "大熊座", 2.06)
    )
    fun starCatalog(): List<SkyStar> = stars.distinctBy { it.name }

    private val lines = listOf(
        "猎户座" to listOf("参宿一", "参宿二", "参宿三", "参宿七", "参宿四"),
        "大熊座" to listOf("天枢", "天璇", "天玑", "天权", "玉衡", "开阳", "摇光"),
        "夏季大三角" to listOf("织女星", "天津四", "牛郎星")
    )

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val loc = location ?: Location("default").apply { latitude = 26.58; longitude = 106.71 }
        val now = Calendar.getInstance()
        val jd = julianDate(now.timeInMillis)
        val lst = (greenwichSiderealTime(jd) + loc.longitude / 15.0 + 24.0) % 24.0
        val points = mutableMapOf<String, SkyPoint>()
        for (star in stars) {
            val (alt, az) = equatorialToHorizontal(star.raHours, star.decDeg, lst, loc.latitude)
            val p = project(az.toFloat(), alt.toFloat()) ?: continue
            points[star.name] = SkyPoint(star, p.first, p.second)
        }
        // Constellation line segments are drawn only when both stars are inside the current view.
        val byName = stars.associateBy { it.name }
        for ((_, names) in lines) {
            for (i in 0 until names.size - 1) {
                val a = points[names[i]]; val b = points[names[i + 1]]
                if (a != null && b != null) canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
            }
        }
        for (point in points.values) {
            val selected = point.star.name == highlightName
            val r = (7.0 - point.star.magnitude).coerceIn(2.5, 8.0).toFloat() + if (selected) 5f else 0f
            if (selected) {
                val halo = android.graphics.Paint(3).apply { color = 0xAA7CFFB2.toInt(); style = android.graphics.Paint.Style.STROKE; strokeWidth = 3f }
                canvas.drawCircle(point.x, point.y, r + 9f, halo)
            }
            canvas.drawCircle(point.x, point.y, r, starPaint)
            canvas.drawText(point.star.name, point.x + 10f, point.y - 8f, textPaint)
            canvas.drawText(point.star.constellation, point.x + 10f, point.y + 18f, labelPaint)
        }
        // Centre reticle
        val cx = width / 2f; val cy = height / 2f
        val p = android.graphics.Paint(3).apply { color = 0xBBFFFFFF.toInt(); strokeWidth = 2f }
        canvas.drawCircle(cx, cy, 18f, p); canvas.drawLine(cx - 28, cy, cx - 8, cy, p); canvas.drawLine(cx + 8, cy, cx + 28, cy, p)
    }

    private fun project(azimuth: Float, altitude: Float): Pair<Float, Float>? {
        // Approximate camera field of view. Heading/pitch calibration varies by device and camera.
        var da = ((azimuth - (heading + headingOffset) + 540f) % 360f) - 180f
        da = ((da + 180f) % 360f) - 180f
        val relAlt = altitude - (pitch + pitchOffset)
        val hfov = 62f; val vfov = 48f
        if (abs(da) > hfov / 2f || abs(relAlt) > vfov / 2f) return null
        val x = width / 2f + (da / hfov) * width
        val y = height / 2f - (relAlt / vfov) * height
        return if (x in 0f..width.toFloat() && y in 0f..height.toFloat()) Pair(x, y) else null
    }

    private fun equatorialToHorizontal(raHours: Double, decDeg: Double, lstHours: Double, latDeg: Double): Pair<Double, Double> {
        val ha = Math.toRadians((lstHours - raHours) * 15.0)
        val dec = Math.toRadians(decDeg); val lat = Math.toRadians(latDeg)
        val sinAlt = sin(dec) * sin(lat) + cos(dec) * cos(lat) * cos(ha)
        val alt = asin(sinAlt.coerceIn(-1.0, 1.0))
        val az = atan2(-sin(ha) * cos(dec), sin(dec) * cos(lat) - cos(dec) * sin(lat) * cos(ha))
        return Pair(Math.toDegrees(alt), (Math.toDegrees(az) + 360.0) % 360.0)
    }
    private fun julianDate(timeMillis: Long): Double = timeMillis / 86400000.0 + 2440587.5
    private fun greenwichSiderealTime(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        var deg = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * t * t - t * t * t / 38710000.0
        deg = (deg % 360.0 + 360.0) % 360.0
        return deg / 15.0
    }
}
